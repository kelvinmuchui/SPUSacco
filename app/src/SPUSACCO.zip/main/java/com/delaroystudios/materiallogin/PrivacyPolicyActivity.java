package com.delaroystudios.materiallogin;

class PrivacyPolicyActivity {
}
