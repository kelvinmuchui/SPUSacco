package com.delaroystudios.materiallogin;

class AboutUsActivity {
}
